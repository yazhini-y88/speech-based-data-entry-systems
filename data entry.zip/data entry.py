import speech_recognition as sr
import pyttsx3
import time

# Initialize the speech recognition and text-to-speech engines
recognizer = sr.Recognizer()
engine = pyttsx3.init()

# Set properties for speech engine (optional, can adjust voice speed, volume, etc.)
engine.setProperty('rate', 150)  # Speed of speech
engine.setProperty('volume', 1)  # Volume level (0.0 to 1.0)

def speak(text):
    engine.say(text)
    engine.runAndWait()

def listen():
    with sr.Microphone() as source:
        print("Listening for your input...")
        recognizer.adjust_for_ambient_noise(source)  # Adjusts for background noise
        audio = recognizer.listen(source)
        try:
            print("Recognizing...")
            # Use Google Web Speech API for speech recognition
            text = recognizer.recognize_google(audio)
            print(f"You said: {text}")
            return text
        except sr.UnknownValueError:
            print("Sorry, I couldn't understand that.")
            speak("Sorry, I couldn't understand that.")
            return None
        except sr.RequestError:
            print("Sorry, there was an error with the speech service.")
            speak("Sorry, there was an error with the speech service.")
            return None

def data_entry_system():
    speak("Welcome to the speech-based data entry system.")
    time.sleep(1)  # Giving a slight delay for the user to hear the message
    speak("Please tell me the information you want to enter.")
    
    # Let the user speak data to be entered
    data = listen()

    if data:
        # Simulate saving data (You can customize this to save to a file, database, etc.)
        print(f"Data entered: {data}")
        speak(f"The data entered is: {data}")
    else:
        speak("No data was entered.")

if __name__ == "__main__":
    data_entry_system()
