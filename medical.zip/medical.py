import speech_recognition as sr

def transcribe_medical_audio():
    recognizer = sr.Recognizer()

    with sr.Microphone() as source:
        print("Please begin dictating your medical notes...")
        recognizer.adjust_for_ambient_noise(source)
        audio = recognizer.listen(source)

        try:
            print("Transcribing...")
            # Google API doesn't have a built-in medical model, but can still do basic transcription
            text = recognizer.recognize_google(audio)
            print("Transcription:")
            print(text)

            # Save to file
            with open("medical_transcription.txt", "w") as file:
                file.write(text)

        except sr.UnknownValueError:
            print("Could not understand the audio.")
        except sr.RequestError as e:
            print(f"API error: {e}")

if __name__ == "__main__":
    transcribe_medical_audio()
